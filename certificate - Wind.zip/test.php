<?php
// Simple test file to verify PHP processing
phpinfo();
?>
