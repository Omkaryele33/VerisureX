-- Update the certificates table to add new fields and modify existing ones

-- Select the database
USE certificate_system;

-- Rename date_of_birth column to issue_date
ALTER TABLE certificates CHANGE COLUMN date_of_birth issue_date DATE NOT NULL;

-- Add new columns for the additional fields
ALTER TABLE certificates 
ADD COLUMN pass_date DATE NULL AFTER issue_date,
ADD COLUMN certificate_number VARCHAR(100) NULL AFTER pass_date,
ADD COLUMN grade ENUM('A', 'A+', 'B', 'B+', 'C', 'C+') NULL AFTER certificate_number,
ADD COLUMN branch_name VARCHAR(100) NULL AFTER grade,
ADD COLUMN validation_status BOOLEAN DEFAULT TRUE AFTER branch_name;

-- Add indexes for better performance
CREATE INDEX idx_certificate_number ON certificates(certificate_number);
