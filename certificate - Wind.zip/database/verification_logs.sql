-- Verification Logs Table
CREATE TABLE IF NOT EXISTS `verification_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `certificate_id` varchar(255) NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `user_agent` text,
  `is_valid` tinyint(1) NOT NULL DEFAULT 0,
  `verified_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_certificate_id` (`certificate_id`),
  KEY `idx_verified_at` (`verified_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Add a foreign key if you want to enforce referential integrity
-- ALTER TABLE `verification_logs` ADD CONSTRAINT `fk_certificate_id` FOREIGN KEY (`certificate_id`) REFERENCES `certificates` (`certificate_id`) ON DELETE CASCADE ON UPDATE CASCADE;
