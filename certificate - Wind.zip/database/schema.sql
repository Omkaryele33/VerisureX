-- Certificate Validation System Database Schema

-- Create database (if not exists)
CREATE DATABASE IF NOT EXISTS certificate_system;
USE certificate_system;

-- Admin users table
CREATE TABLE IF NOT EXISTS admins (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    role ENUM('admin', 'editor') NOT NULL DEFAULT 'editor',
    name VARCHAR(100) NULL,
    password_change_required TINYINT(1) DEFAULT 0,
    account_status VARCHAR(20) DEFAULT 'active',
    login_attempts INT DEFAULT 0,
    last_login DATETIME,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Certificates table
CREATE TABLE IF NOT EXISTS certificates (
    id INT AUTO_INCREMENT PRIMARY KEY,
    certificate_id VARCHAR(36) NOT NULL UNIQUE COMMENT 'UUIDv4 format',
    certificate_number VARCHAR(50) UNIQUE,
    full_name VARCHAR(100) NOT NULL,
    date_of_birth DATE,
    certificate_content TEXT NOT NULL,
    photo_path VARCHAR(255),
    qr_code_path VARCHAR(255),
    additional_info TEXT,
    template_id INT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    created_by INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (created_by) REFERENCES admins(id)
);

-- Verification logs table
CREATE TABLE IF NOT EXISTS verification_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    certificate_id VARCHAR(36) NOT NULL,
    ip_address VARCHAR(45) NOT NULL,
    user_agent VARCHAR(255),
    device_type VARCHAR(50) DEFAULT NULL,
    browser VARCHAR(100) DEFAULT NULL,
    operating_system VARCHAR(100) DEFAULT NULL,
    country VARCHAR(100) DEFAULT NULL,
    city VARCHAR(100) DEFAULT NULL,
    successful TINYINT(1) DEFAULT 1,
    verified_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (certificate_id) REFERENCES certificates(certificate_id)
);

-- Delete admin user if it exists to avoid duplicate entry errors
DELETE FROM admins WHERE username = 'admin';

-- Create default admin user (password: admin123)
INSERT INTO admins (username, email, password, role, name) 
VALUES ('admin', 'admin@example.com', '$2y$10$8tPkYDhONVSKRrYFDaF1HeZUcx1Uy9yZQVNQV.QCrIZVPgLDRHgLe', 'admin', 'System Administrator');

-- Add indexes only if they don't exist
-- These will help with performance
CREATE INDEX IF NOT EXISTS idx_certificate_id ON certificates(certificate_id);
CREATE INDEX IF NOT EXISTS idx_verification_logs_certificate_id ON verification_logs(certificate_id);
