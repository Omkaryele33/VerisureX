<?php
/**
 * Security Header
 * This file now simply includes the master initialization file
 */

require_once "master_init.php";
