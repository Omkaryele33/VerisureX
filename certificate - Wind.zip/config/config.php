<?php
/**
 * Configuration File
 * This file contains database credentials and other configuration settings
 */

// Include constants first if they haven't been included yet
if (!defined('BASE_URL')) {
    require_once __DIR__ . "/constants.php";
}

// Include secure database configuration
require_once __DIR__ . "/../secure_config/db_config.php";

// Error reporting
ini_set("display_errors", 1);
ini_set("display_startup_errors", 1);
error_reporting(E_ALL);

// Log any database connection errors
if (isset($dbError)) {
    error_log('[Config] ' . $dbError);
}

ini_set("display_startup_errors", 1);
error_reporting(E_ALL);